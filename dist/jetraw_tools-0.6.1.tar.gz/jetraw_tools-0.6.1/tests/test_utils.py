import unittest
import numpy as np
from jetraw_tools.dpcore import prepare_image


class TestDpcore(unittest.TestCase):
    def test_prepare_image(self):
        # Create a sample image
        test_image = np.random.randint(0, 65535, size=(100, 100), dtype=np.uint16)

        # Test successful preparation
        try:
            result = prepare_image(test_image, "A22D723023_DynamicRange")
            print(result)
        except Exception as e:
            self.fail(f"prepare_image failed: {e}")

    def test_prepare_image_wrong_identifier(self):
        # Create a sample image
        test_image = np.random.randint(0, 65535, size=(100, 100), dtype=np.uint16)

        # Test preparation with wrong identifier
        with self.assertRaises(RuntimeError) as context:
            prepare_image(test_image, "Fake_identifier")

        # Optional: Check the specific error message
        self.assertTrue("No parameters for given identifier" in str(context.exception))


if __name__ == "__main__":
    unittest.main()
