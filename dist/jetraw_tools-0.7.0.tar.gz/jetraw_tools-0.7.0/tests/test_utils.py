import unittest
import numpy as np
import os
from jetraw_tools.dpcore import prepare_image

def is_jetraw_environment_configured():
    """
    Checks if 'jetraw' (case-insensitive) is found in relevant environment variables,
    suggesting a JetRaw installation is configured in the environment.
    """
    env_vars_to_check = [
        os.environ.get("PATH", ""),
        os.environ.get("DYLD_FALLBACK_LIBRARY_PATH", ""),
        os.environ.get("LD_LIBRARY_PATH", "")
    ]
    
    for var_value in env_vars_to_check:
        if "jetraw" in var_value.lower():
            return True
    return False

# Run the test only if jetraw is in the environment variables.
JETRAW_ENV_CONFIGURED = is_jetraw_environment_configured()
SKIP_REASON_JETRAW_NOT_CONFIGURED = (
    "Skipping JetRaw dependent tests: JetRaw installation not detected in environment "
    "variables (PATH, DYLD_FALLBACK_LIBRARY_PATH, LD_LIBRARY_PATH)."
)

@unittest.skipUnless(JETRAW_ENV_CONFIGURED, SKIP_REASON_JETRAW_NOT_CONFIGURED)
class TestPrepareImage(unittest.TestCase):
    """Test suite for the prepare_image function from dpcore module."""

    def setUp(self):
        """Set up a sample image for use in tests."""
        self.sample_image = np.random.randint(0, 65535, size=(100, 100), dtype=np.uint16)
        self.valid_identifier = "A22D723023_DynamicRange"
        self.invalid_identifier = "Fake_Identifier_123"

    def test_successful_preparation(self):
        """
        Tests that prepare_image runs successfully with a valid identifier
        and returns a NumPy array.
        """
        try:
            result = prepare_image(self.sample_image, self.valid_identifier)
            self.assertIsNotNone(result, "prepare_image should return a result.")
            self.assertIsInstance(result, np.ndarray, "prepare_image should return a NumPy array.")

        except Exception as e:
            self.fail(f"prepare_image raised an unexpected exception with a valid identifier: {e}")

    def test_preparation_with_wrong_identifier(self):
        """
        Tests that prepare_image raises a RuntimeError when an invalid
        identifier is provided.
        """
        with self.assertRaises(RuntimeError) as context:
            prepare_image(self.sample_image, self.invalid_identifier)

        self.assertTrue(
            "No parameters for given identifier" in str(context.exception).lower() or
            "unknown identifier" in str(context.exception).lower(),
            f"Error message '{str(context.exception)}' did not contain expected substring."
        )


if __name__ == "__main__":
    unittest.main()
