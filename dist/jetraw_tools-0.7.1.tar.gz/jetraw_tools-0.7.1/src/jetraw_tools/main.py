from jetraw_tools.parser import app


if __name__ == "__main__":
    app()
